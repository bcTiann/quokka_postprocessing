# Quokka2s
A Python pipeline for post-processing QUOKKA R-MHD simulation data and generating synthetic observations.

## Installation
```bash
pip install quokka2s